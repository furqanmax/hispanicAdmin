<?php

namespace App\Http\Controllers;

use App\BadWord;
use Illuminate\Http\Request;

class BadWordController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\BadWord  $badWord
     * @return \Illuminate\Http\Response
     */
    public function show(BadWord $badWord)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\BadWord  $badWord
     * @return \Illuminate\Http\Response
     */
    public function edit(BadWord $badWord)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\BadWord  $badWord
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, BadWord $badWord)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\BadWord  $badWord
     * @return \Illuminate\Http\Response
     */
    public function destroy(BadWord $badWord)
    {
        //
    }
}
