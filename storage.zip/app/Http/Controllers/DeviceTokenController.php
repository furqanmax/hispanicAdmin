<?php

namespace App\Http\Controllers;

use App\DeviceToken;
use Illuminate\Http\Request;

class DeviceTokenController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\DeviceToken  $deviceToken
     * @return \Illuminate\Http\Response
     */
    public function show(DeviceToken $deviceToken)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\DeviceToken  $deviceToken
     * @return \Illuminate\Http\Response
     */
    public function edit(DeviceToken $deviceToken)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\DeviceToken  $deviceToken
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DeviceToken $deviceToken)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\DeviceToken  $deviceToken
     * @return \Illuminate\Http\Response
     */
    public function destroy(DeviceToken $deviceToken)
    {
        //
    }
}
