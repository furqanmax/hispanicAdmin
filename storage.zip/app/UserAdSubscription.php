<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserAdSubscription extends Model
{
    //
}
