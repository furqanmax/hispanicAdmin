<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserMembershipPlan extends Model
{
    //
}
