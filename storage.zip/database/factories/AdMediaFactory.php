<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\AdMedia;
use Faker\Generator as Faker;

$factory->define(AdMedia::class, function (Faker $faker) {
    return [
        //
    ];
});
