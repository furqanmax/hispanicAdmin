<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\AdSubscription;
use Faker\Generator as Faker;

$factory->define(AdSubscription::class, function (Faker $faker) {
    return [
        //
    ];
});
