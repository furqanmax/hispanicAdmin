<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\BadWord;
use Faker\Generator as Faker;

$factory->define(BadWord::class, function (Faker $faker) {
    return [
        //
    ];
});
