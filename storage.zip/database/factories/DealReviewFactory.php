<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\DealReview;
use Faker\Generator as Faker;

$factory->define(DealReview::class, function (Faker $faker) {
    return [
        //
    ];
});
