<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\DealSale;
use Faker\Generator as Faker;

$factory->define(DealSale::class, function (Faker $faker) {
    return [
        //
    ];
});
