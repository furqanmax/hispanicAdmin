<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\MembershipPlan;
use Faker\Generator as Faker;

$factory->define(MembershipPlan::class, function (Faker $faker) {
    return [
        //
    ];
});
