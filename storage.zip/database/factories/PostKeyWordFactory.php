<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\PostKeyWord;
use Faker\Generator as Faker;

$factory->define(PostKeyWord::class, function (Faker $faker) {
    return [
        //
    ];
});
