<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\UserAdSubscription;
use Faker\Generator as Faker;

$factory->define(UserAdSubscription::class, function (Faker $faker) {
    return [
        //
    ];
});
