<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\UserMembershipPlan;
use Faker\Generator as Faker;

$factory->define(UserMembershipPlan::class, function (Faker $faker) {
    return [
        //
    ];
});
