<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAlertsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('alerts', function (Blueprint $table) {
            $table->id();

            $table->string('message')->nullable()->default(null);
            $table->timestamp('time')->nullable()->default(null);
            $table->string('channel',20)->nullable()->default(null);
            $table->string('status',50)->nullable()->default(null);

            $table->bigInteger('userId')->unsigned();


            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('alerts');
    }
}
